CREATE TABLE [dbo].[fact_leads] (

	[LeadID] int NULL, 
	[ClientID] int NULL, 
	[PropertyID] int NULL, 
	[CampaignID] int NULL, 
	[LeadDate] date NULL, 
	[LeadSource] varchar(8000) NULL
);


GO
ALTER TABLE [dbo].[fact_leads] ADD CONSTRAINT FK_c350dac9_40e2_47cb_b115_5fded8635a02 FOREIGN KEY ([CampaignID]) REFERENCES [dbo].[dim_campanha]([CampaignID]);
GO
ALTER TABLE [dbo].[fact_leads] ADD CONSTRAINT FK_fa4bc87b_2132_4f09_be79_78268fe67f68 FOREIGN KEY ([ClientID]) REFERENCES [dbo].[dim_clientes]([ClientID]);