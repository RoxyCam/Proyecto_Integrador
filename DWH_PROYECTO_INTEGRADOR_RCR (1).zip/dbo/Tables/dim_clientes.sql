CREATE TABLE [dbo].[dim_clientes] (

	[ClientID] int NULL, 
	[FirstName] varchar(8000) NULL, 
	[LastName] varchar(8000) NULL, 
	[Email] date NULL, 
	[Region] int NULL
);


GO
ALTER TABLE [dbo].[dim_clientes] ADD CONSTRAINT UQ_a4b39ccc_a015_4b4d_b598_40651ea7ad47 unique NONCLUSTERED ([ClientID]);