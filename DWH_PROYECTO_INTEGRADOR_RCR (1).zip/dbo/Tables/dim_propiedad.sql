CREATE TABLE [dbo].[dim_propiedad] (

	[PropertyID] int NULL, 
	[ProjectID] int NULL, 
	[PropertyType] varchar(8000) NULL, 
	[Size_m2] int NULL, 
	[Bedrooms] int NULL, 
	[Bathrooms] int NULL, 
	[ListPriceUSD] int NULL, 
	[AvailabilityStatus] varchar(8000) NULL
);


GO
ALTER TABLE [dbo].[dim_propiedad] ADD CONSTRAINT UQ_e7034a77_4b73_40a8_91ad_a71ff49f2221 unique NONCLUSTERED ([PropertyID]);