CREATE TABLE [dbo].[dim_corredor] (

	[BrokerID] int NULL, 
	[BrokerName] varchar(8000) NULL, 
	[Region] varchar(8000) NULL, 
	[email] varchar(8000) NULL
);


GO
ALTER TABLE [dbo].[dim_corredor] ADD CONSTRAINT UQ_83422265_1565_4b87_b1be_cdcc26198d07 unique NONCLUSTERED ([BrokerID]);