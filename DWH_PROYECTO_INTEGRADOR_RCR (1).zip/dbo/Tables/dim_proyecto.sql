CREATE TABLE [dbo].[dim_proyecto] (

	[ProjectID] int NULL, 
	[ProjectName] varchar(8000) NULL, 
	[City] varchar(8000) NULL, 
	[Region] varchar(8000) NULL, 
	[LaunchYear] varchar(8000) NULL, 
	[Status] varchar(8000) NULL
);