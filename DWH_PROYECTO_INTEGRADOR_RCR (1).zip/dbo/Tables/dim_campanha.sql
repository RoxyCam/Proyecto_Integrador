CREATE TABLE [dbo].[dim_campanha] (

	[CampaignID] int NULL, 
	[Channel] varchar(8000) NULL, 
	[CampaignName] varchar(8000) NULL, 
	[StartDate] date NULL, 
	[BudgetUSD] int NULL
);


GO
ALTER TABLE [dbo].[dim_campanha] ADD CONSTRAINT UQ_0cba4d81_b8d6_4d6e_b68e_27406969a618 unique NONCLUSTERED ([CampaignID]);