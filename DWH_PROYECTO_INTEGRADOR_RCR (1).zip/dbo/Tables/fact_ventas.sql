CREATE TABLE [dbo].[fact_ventas] (

	[SaleID] int NULL, 
	[PropertyID] int NULL, 
	[ClientID] int NULL, 
	[BrokerID] int NULL, 
	[SaleDate] date NULL, 
	[SalePriceUSD] int NULL
);


GO
ALTER TABLE [dbo].[fact_ventas] ADD CONSTRAINT FK_4db0886b_4c26_4c2b_969e_501ba27c03f2 FOREIGN KEY ([ClientID]) REFERENCES [dbo].[dim_clientes]([ClientID]);
GO
ALTER TABLE [dbo].[fact_ventas] ADD CONSTRAINT FK_d3a99ced_0c50_4085_a99c_b4cb3a049ce1 FOREIGN KEY ([PropertyID]) REFERENCES [dbo].[dim_propiedad]([PropertyID]);
GO
ALTER TABLE [dbo].[fact_ventas] ADD CONSTRAINT FK_d8a5f840_e291_403b_bb5e_940acf4b5a6d FOREIGN KEY ([BrokerID]) REFERENCES [dbo].[dim_corredor]([BrokerID]);